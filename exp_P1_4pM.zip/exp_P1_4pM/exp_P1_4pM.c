const float alpha[4]={ 0.75682846f, 0.90002579f, 1.0703171f, 1.272828678f};
const int beta[3]={ 0, -300307, -1014560, -2288653};// błąd 4 element
float exp_P1_4pM(float x)
{ 
float y;
int  j ; 
int z=x*0xb8aa3b + 0x3f800000;
int zii=z&0x7f800000; 
int zif=z&0x007fffff;
j=zif>>21;
zif=(int)(zif*alpha[j]+beta[j]);
zii |=zif; 
y=*(float*)&zii;
y*=0.998127527f;
return y; 
}
