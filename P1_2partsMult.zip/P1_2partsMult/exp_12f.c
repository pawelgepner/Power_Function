#include <ap_cint.h>

const float alpha[2]={ 0.8284271247f, 1.171572875f};
const int beta[2]={ 0,-1439258};

float exp_12f(float x)
{
float y;
int  j;
int z=x*0xb8aa3b + 0x3f800000;
int zii=z&0x7f800000;
int zif=z&0x007fffff;
j=zif>>22;
zif=(int)(zif*alpha[j]+beta[j]);
zii |=zif;
y=*(float*)&zii;
y*=0.9925613f;
return y;
}
