# 1 "/tools/P1_2Parts_Mult/main.c"
# 1 "/tools/P1_2Parts_Mult/main.c" 1
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 149 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/tools/P1_2Parts_Mult/main.c" 2


float y, x = 3.02574920654296875f;

int main(){

y = exp_12f(x);

return 0;


}
