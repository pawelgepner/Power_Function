// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
# 1 "/tools/P1_2Parts_Mult/main.c"
# 1 "/tools/P1_2Parts_Mult/main.c" 1
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 149 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/tools/P1_2Parts_Mult/main.c" 2


float y, x = 3.02574920654296875f;


#ifndef HLS_FASTSIM
#ifdef __cplusplus
extern "C"
#endif
int apatb_exp_12f_sw();
# 5 "/tools/P1_2Parts_Mult/main.c"
int main(){

y = 
#ifndef HLS_FASTSIM
#define exp_12f apatb_exp_12f_sw
#endif
# 7 "/tools/P1_2Parts_Mult/main.c"
exp_12f(x);
#undef exp_12f
# 7 "/tools/P1_2Parts_Mult/main.c"


return 0;


}
#endif
# 12 "/tools/P1_2Parts_Mult/main.c"

