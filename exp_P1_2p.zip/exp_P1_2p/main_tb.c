float y, x = 3.02574920654296875f;

int main(){

y = exp_12f(x); //pow2_18int(x);

return 0;


}
