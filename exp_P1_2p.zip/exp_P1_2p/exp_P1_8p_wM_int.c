#include "ap_cint.h"

const int alpha[8]={ 6027202, 6620496,7219702 ,7873141,8585721, 9362795,10210201,11134303};
const int beta[8]={ 0,-72620,-222421,-467461,-823751,-1309422,-1944976,-2753566};
float exp_P1_8p_wM_int(float x)

{
int z,zii,zif, j;
z=x*0x00800000 + 0x3f800000;
zii=z&0x7f800000;
zif=z&0x007fffff;
j=zif>>20;
zif=(int)((zif*(int64) alpha[j])>>23)+beta[j];
zii |=zif;
float y=*(float*)&zii;
return y;
}
